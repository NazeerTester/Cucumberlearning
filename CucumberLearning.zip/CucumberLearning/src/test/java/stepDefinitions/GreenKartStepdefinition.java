package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.Iterator;
import java.util.Set;



    public class GreenKartStepdefinition {

        public WebDriver driver;
        public String landingpageproductname;
        public String offerproductpage;

        @Given("User is  on Green Cart page")
        public void user_is_on_green_cart_page() {

            System.setProperty("webdriver.chrome.driver","C:/SRDEV/chromedriver/chromedriver.exe");
            WebDriverManager.chromedriver().setup();

            driver = new ChromeDriver();
            driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
        }
        @When("user search with shortname called {string} and extracted actual name of the product")
        public void user_search_with_shortname_called_and_extracted_actual_name_of_the_product(String shortname) throws InterruptedException {
            // Write code here that turns the phrase above into concrete actions
            driver.findElement(By.xpath("//input[@type='search']")).sendKeys(shortname);
            Thread.sleep(2000);
            landingpageproductname  = driver.findElement(By.cssSelector("h4.product-name")).getText().split("-")[0].trim();
            System.out.println(landingpageproductname + "extracted from the page");
        }

        @Then("user is searched for {string} in offers page")
        public void user_is_searched_for_in_offers_page(String shortname) throws InterruptedException {
            // Write code here that turns the phrase above into concrete actions
            driver.findElement(By.linkText("Top Deals")).click();
            Set<String> s1= driver.getWindowHandles();
            Iterator<String> i1= s1.iterator();
            String parentwindow =i1.next();
            String childwindow =i1.next();
            driver.switchTo().window(childwindow);


            driver.findElement(By.xpath("//input[@type='search']")).sendKeys(shortname);
            Thread.sleep(2000);
            offerproductpage =driver.findElement(By.cssSelector("tbody tr td:nth-child(1)")).getText();


        }

        @Then("validate the product name in offers page with Landing page")
        public void validate_the_product_name_in_offers_page_with_landing_page() {

            Assert.assertEquals(offerproductpage,landingpageproductname);

        }




    }
