package stepDefinition;


import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {

    @Before("@Mobiletest")
    public void  beforevalidation()
    {
       System.out.println("Mobile test running for before hooks");
    }


    @After("@Mobiletest")
    public void  aftervalidation()
    {
        System.out.println("Mobile test running after hooks");
    }

    @Before("@Webtest")
    public void  beforewebtestvalidation()
    {
        System.out.println("Mobile test running for before webtest hooks");
    }


    @After("@Webtest")
    public void  afterwebtestvalidation()
    {
        System.out.println("Mobile test running after webtest hooks");
    }
}
