package stepDefinition;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import utils.TestContextSetup;

public class LandingpageStepDefinition {

    public WebDriver driver;
    public String landingpageproductname;
    public String offerproductpage;
    TestContextSetup testContextSetup;

    public LandingpageStepDefinition(TestContextSetup testContextSetup) /// // constructor : we are passing instance of TestContextsetup
    // testContextSetup is a instance of TestContextSetup

    {
      this.testContextSetup= testContextSetup;

    }

    @Given("User is  on Green Cart page")
    public void user_is_on_green_cart_page() {
        // Write code here that turns the phrase above into concrete actions

        System.setProperty("webdriver.chrome.driver","C:\\SRDEV\\chromedriver\\chromedriver.exe");
        WebDriverManager.chromedriver().setup();
        testContextSetup.driver = new ChromeDriver();
        testContextSetup.driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");


    }

    @When("user search with shortname called {string} and extracted actual name of the product")
    public void user_search_with_shortname_called_and_extracted_actual_name_of_the_product(String shortname) throws InterruptedException {
        // Write code here that turns the phrase above into concrete actions
        testContextSetup.driver.findElement(By.xpath("//input[@type='search']")).sendKeys(shortname);
        Thread.sleep(2000);
        testContextSetup.landingpageproductname  = testContextSetup.driver.findElement(By.cssSelector("h4.product-name")).getText().split("-")[0].trim();
        System.out.println(landingpageproductname + "extracted from the page");
    }




}



