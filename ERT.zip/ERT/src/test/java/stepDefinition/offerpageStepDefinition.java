package stepDefinition;

import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import utils.TestContextSetup;

import java.util.Iterator;
import java.util.Set;

public class offerpageStepDefinition {

    public WebDriver driver;
    public String landingpageproductname;
    public String offerproductpage;
    TestContextSetup testContextSetup;


    public offerpageStepDefinition(TestContextSetup testContextSetup) /// constructor : we are passing instance of TestContextsetup
            // testContextSetup is a instance of TestContextSetup
    {
        this.testContextSetup= testContextSetup;
    }

    @Then("user is searched for {string} in offers page")
    public void user_is_searched_for_in_offers_page(String shortname) throws InterruptedException {
        // Write code here that turns the phrase above into concrete actions
        testContextSetup.driver.findElement(By.linkText("Top Deals")).click();
        Set<String> s1= testContextSetup.driver.getWindowHandles();
        Iterator<String> i1= s1.iterator();
        String parentwindow =i1.next();
        String childwindow =i1.next();
        testContextSetup.driver.switchTo().window(childwindow);


        testContextSetup.driver.findElement(By.xpath("//input[@type='search']")).sendKeys(shortname);
        Thread.sleep(2000);
        String offerproductpage =testContextSetup.driver.findElement(By.cssSelector("tbody tr td:nth-child(1)")).getText();


    }

    @Then("validate the product name in offers page with Landing page")
    public void validate_the_product_name_in_offers_page_with_landing_page(){

        Assert.assertEquals(offerproductpage,testContextSetup.landingpageproductname);

    }



}



