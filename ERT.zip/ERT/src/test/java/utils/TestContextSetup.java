package utils;


import org.openqa.selenium.WebDriver;

public class TestContextSetup {
    public WebDriver driver; //Declared the driver
    public String landingpageproductname; //declared the landingpageproductname variable

}
